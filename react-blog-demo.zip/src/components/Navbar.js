import React from 'react';
import {Link, NavLink} from 'react-router-dom';

function Navbar () {

  return (

    <nav className="navbar  navbar-default container-fluid">
    <div className="container">
      <div className="navbar-header">
        <a className="navbar-brand" href="#"> <span className="glyphicon glyphicon-eye-open"></span> FAK Posts</a>
      </div>
      <ul className="nav navbar-nav float-right">
        <li className="active"><NavLink to="/"> Home</NavLink></li>
        <li><NavLink  to="/posts">Posts</NavLink></li>
        <li><NavLink to="/contact">Contact Us</NavLink></li>
      </ul>
    </div>
  </nav>
  );
}

export default Navbar;
