import React, { Component } from 'react'

class Posts extends Component {
  render() {
    return (
      <div className="container">
            <h2>Posts Page</h2>
      </div>
    )
  }
}

export default Posts
