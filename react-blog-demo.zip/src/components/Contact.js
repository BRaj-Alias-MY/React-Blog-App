import React, { Component } from 'react'

class Contact extends Component {
  render() {
    return (
      <div className="container">
      <h2>Contact Page</h2>
      </div>
    )
  }
}

export default Contact
