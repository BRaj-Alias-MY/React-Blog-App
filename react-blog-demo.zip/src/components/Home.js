import React, { Component } from 'react'
import axios from 'axios';
import Result from './Result';

class Home extends Component {
    constructor(props) {
      super(props)

      this.state = {
            posts : [],
            per: 5,
            page: 1,
            totalPages: null,
      }
    }
    componentWillMount(){
     //   console.log(this.state);
       this.loadPosts();
      }

      loadPosts () {
        const {per, page, posts} = this.state;
        const url = `https://student-example-api.herokuapp.com/v1/contacts.json?per=${per}&page=${page}`;
        axios
          .get (url)
          .then (json => {
            console.log(json.data);
            this.setState ({

              posts: [...posts,...json.data.contacts ],

            });
          })
          .catch (err => console.log (err));
      }

      loadMore = () => {
        this.setState (
          prevState => ({
            page: prevState.page + 1,
          }),
          this.loadPosts
        );
      };


  render() {
    return (
      <div className="container">
        <div className="row">
        <div className="col-md-8">
        <div className="panel panel-default">
        <div className="panel-heading">Welcome to React Posts</div>
        <div className="panel-body" >
        <div className="post">
        {this.state.posts.map (post => (
            <div className="card" key={post.id}>
              <Result {...post} />
            </div>
          ))}
      </div>

      <button type="button" className="btn btn-primary" onClick={this.loadMore}>Load More</button>
        </div>
      </div>
        </div>
        <div className="col-md-4">

        <div className="panel panel-default">
        <div className="panel-heading">Recent Posts</div>
        <div className="panel-body">Recent Posts Here</div>
        </div>
        </div>

        </div>
      </div>
    )
  }
}

export default Home
