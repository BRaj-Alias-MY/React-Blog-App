import React, { Component } from 'react';
import {BrowserRouter, Route, Switch} from 'react-router-dom';
import './App.css';
import axios from 'axios';
import Navbar from './components/Navbar';
import Home from './components/Home';
import Posts from './components/Posts';
import Contact from './components/Contact'

class App extends Component {

  constructor(props) {
    super(props)

    this.state = {
       posts: []
    }
  }


  render() {
    return (
      <BrowserRouter>
      <div>
      <Navbar />

      <Switch>
      <Route path="/" exact component={Home} />
      <Route path="/posts" component={Posts} />
      <Route path="/contact" component={Contact} />

    </Switch>

      </div>
      </BrowserRouter>

    );
  }
}

export default App;
